﻿<?php
session_start();
require('../php-includes/connect.php');
require('../php-includes/function.php');
require('../function/table-data.php');
require('php-includes/check_login.php');

//$basename = explode('.',basename($_SERVER['PHP_SELF']));
//$page = $basename[0];
$page = "join";
$userid = $_SESSION['userid'];
$user_data = user($userid);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Dalfay | New Joining</title>
    
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Colorpicker Css -->
    <link href="plugins/bootstrap-colorpicker/css/bootstrap-colorpicker.css" rel="stylesheet" />

    <!-- Dropzone Css -->
    <link href="plugins/dropzone/dropzone.css" rel="stylesheet">

    <!-- Multi Select Css -->
    <link href="plugins/multi-select/css/multi-select.css" rel="stylesheet">

    <!-- Bootstrap Spinner Css -->
    <link href="plugins/jquery-spinner/css/bootstrap-spinner.css" rel="stylesheet">

    <!-- Bootstrap Tagsinput Css -->
    <link href="plugins/bootstrap-tagsinput/bootstrap-tagsinput.css" rel="stylesheet">

    <!-- Bootstrap Select Css -->
    <link href="plugins/bootstrap-select/css/bootstrap-select.css" rel="stylesheet" />

    <!-- noUISlider Css -->
    <link href="plugins/nouislider/nouislider.min.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
    
    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
    
    <!-- Bootstrap Material Datetime Picker Css -->
    <link href="plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="/resources/demos/style.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <link rel="stylesheet" href="/resources/demos/style.css">

 	<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>	
	<script>
		$( function() {
		$( "#birthdate" ).datepicker(
			{
				changeMonth: true,
      			changeYear: true,
				minDate: "-80Y", 
        		maxDate: "-17Y",
         		yearRange: "1955:2005",
				dateFormat: 'yy-mm-dd'
				//maxDate: "+1M +10D"
			});
		} );
  	</script>
   
</head>

<body class="theme-red" id="body">
    <?php include('php-includes/header.php'); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h3>New Joining</h3>
            </div>

            <!-- Widgets -->
            
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card" id="card">
                    	<form id="join_form">
                            <div class="header">
                                <h2>User Detail</h2>
                            </div>
                            <div class="body demo-masked-input">
                                <div class="row clearfix">
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">person</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="firstname" class="form-control" placeholder="First Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">person</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="middlename" class="form-control" placeholder="Middle Name">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">person</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="lastname" class="form-control" placeholder="Last Name">
                                            </div>
                                        </div>
                                    </div>
                                </div><!--/.row-->
                                <div class="row clearfix">
                                	<div class="col-md-4">
                                        <div class="form-group">
                                            <input type="radio" name="gender" id="male" value="male" class="with-gap">
                                            <label for="male">Male</label>
        
                                            <input type="radio" name="gender" id="female" value="female" class="with-gap">
                                            <label for="female" class="m-l-20">Female</label>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">phone</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="mobile" class="form-control mobile-phone-number" placeholder="Ex: +00 (000) 000-00-00">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">date_range</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" id="birthdate" name="birthdate" class="form-control" placeholder="dd-mm-yy">
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div><!--/.row-->
                                <div class="row">
                                	<div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">email</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="email" class="form-control email" placeholder="Ex: example@example.com">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">person</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="paypal" class="form-control" placeholder="Pay Pal Account(Optional)">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                    	<div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">person</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="referral_user" id="referral_user" class="form-control" placeholder="Referral User">
                                            </div>
                                            <b><p id="referral_user_name"></p></b>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                	<div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                    <i class="material-icons">room</i>
                                            </span>
                                            <div class="form-line">
                                            	<input type="text" name="country" class="form-control" placeholder="Country">
                                          	</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                    <i class="material-icons">room</i>
                                            </span>
                                            <div class="form-line">
                                            	<input type="text" name="state" class="form-control" placeholder="State">
                                          	</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">room</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="city" class="form-control" placeholder="City">
                                            </div>
                                        </div>
                                    </div>
                                </div><!--/.row-->
                                <div class="row">
                                	<div class="col-md-4">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">room</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="pincode" class="form-control pincode" placeholder="Pincode">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="input-group">
                                            <span class="input-group-addon">
                                                <i class="material-icons">map</i>
                                            </span>
                                            <div class="form-line">
                                                <input type="text" name="address" class="form-control" placeholder="Street">
                                            </div>
                                        </div>
                                    </div>
                                </div><!--/.row-->
                                <div class="row">
                                	<div class="col-md-12">
                                    	<div class="demo-checkbox">
                                        	<input type="checkbox" id="terms" class="filled-in" />											<label for="terms">I read & accept all the terms & conditions.</label>
                                        </div>
                                    </div>
                                </div><!--/.row-->
                                <div class="row" align="center">
                                    <div class="col-md-2">
                                    	<div class="form-group">
                                        	<input type="submit" id="join" name="join" value="Join" class="btn btn-primary">
                                     	</div>
                                        <div class="demo-preloader" id="wait" style="display:none">
                                            <div class="preloader">
                                                <div class="spinner-layer">
                                                    <div class="circle-clipper left">
                                                        <div class="circle"></div>
                                                    </div>
                                                    <div class="circle-clipper right">
                                                        <div class="circle"></div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-2">
                                    	<div class="form-group">
                                        	<input type="reset" name="reset" class="btn btn-default">
                                       	</div>
                                    </div>
                            	</div><!--/.row-->
                            </div><!--/.body-->
                       	</form>
                  	</div>
                </div>
            </div>
            <!-- #END# Content -->
        </div>
    </section>

	
     <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Bootstrap Colorpicker Js -->
    <script src="plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>

    <!-- Dropzone Plugin Js -->
    <script src="plugins/dropzone/dropzone.js"></script>

    <!-- Input Mask Plugin Js -->
    <script src="plugins/jquery-inputmask/jquery.inputmask.bundle.js"></script>

    <!-- Multi Select Plugin Js -->
    <script src="plugins/multi-select/js/jquery.multi-select.js"></script>

    <!-- Jquery Spinner Plugin Js -->
    <script src="plugins/jquery-spinner/js/jquery.spinner.js"></script>

    <!-- Bootstrap Tags Input Plugin Js -->
    <script src="plugins/bootstrap-tagsinput/bootstrap-tagsinput.js"></script>

    <!-- noUISlider Plugin Js -->
    <script src="plugins/nouislider/nouislider.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>
    
	<!-- Bootstrap Material Datetime Picker Plugin Js -->
    <script src="plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/forms/advanced-form-elements.js"></script>
    <script src="js/pages/forms/basic-form-elements.js"></script>
    <script src="js/pages/ui/notifications.js"></script>
    <script src="plugins/bootstrap-notify/bootstrap-notify.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
    <script>
		$("form#join_form").submit(function(){
			var formData = new FormData($(this)[0]);
			if($("#terms").is(':checked')){
				$("#wait").show();
				$.post("ajax/join/join.php", $("#join_form").serialize(), function(data){
					if(parseInt(data)==1){
						$("#wait").hide();
						$("#card").empty();
						$("#card").html("<br><h3>User registration successfull. Userid and password has sent to the user's email ID.</h3><br>");
						window.location.assign("#body");
					}
					else{
						$("#wait").hide();
						show_alert(data);
					}
				});
			}
			else{
				$("#wait").hide();
				show_alert("Please accept our terms & conditions");
			}
			return false;
		});
		
		$("#referral_user").change(function(data){
			var referral_user = $("#referral_user").val();
			if(referral_user!=""){
				$.post("ajax/join/get_referral_user_name.php",{
					referral_user:referral_user
					}, 
					function(data){
						$("#referral_user_name").html(data);
				});	
			}
			else{
				$("#referral_user_name").html("");
			}
		});
    
	</script>
   
</body>

</html>