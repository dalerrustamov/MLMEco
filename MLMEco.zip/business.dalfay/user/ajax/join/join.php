<?php
session_start();
$login_user = $_SESSION['userid'];
if(isset($_POST['firstname'])){
include("../../../php-includes/connect.php");
	$firstname = mysqli_real_escape_string($con,$_POST['firstname']);
	$middlename = mysqli_real_escape_string($con,$_POST['middlename']);
	$lastname = mysqli_real_escape_string($con,$_POST['lastname']);
	$mobile = mysqli_real_escape_string($con,$_POST['mobile']);
	$birthdate = mysqli_real_escape_string($con,$_POST['birthdate']);
	$email = mysqli_real_escape_string($con,$_POST['email']);
	$paypal = mysqli_real_escape_string($con,$_POST['paypal']);
	$address = mysqli_real_escape_string($con,$_POST['address']);
	$state = mysqli_real_escape_string($con,$_POST['state']);
	$city = mysqli_real_escape_string($con,$_POST['city']);
	$pincode = mysqli_real_escape_string($con,$_POST['pincode']);
	$country = mysqli_real_escape_string($con,$_POST['country']);
	$referral_user = mysqli_real_escape_string($con,$_POST['referral_user']);
	$date = date("Y-m-d");
	$password = rand(100000,999999);
	
	if(isset($_POST['gender'])){
		$gender = mysqli_real_escape_string($con,$_POST['gender']);
	}
	else{
		$gender = "";
	}
	
	$flag=0;	
	check_empty_field($firstname,$lastname,$gender,$mobile,$birthdate,$email,$country,$address,$state,$city,$pincode,$referral_user);
	if($flag==0){
		//No filed is empty
		if(check_valid_userid($email)){
			//Valid email id
			if(!check_valid_userid($referral_user)){
				//If referral_user is available
				mysqli_autocommit($con,FALSE);

				// Insert some values 
				
				//Insert into user
				$query1 = mysqli_query($con,"insert into user(`email`,`firstname`,`middlename`,`lastname`,`gender`,`dob`,`state`,`city`,`address`,`country`,`pincode`,`mobileno`,`password`,`paypal`,`date`,`referral_user`,`by_userid`) values('$email','$firstname','$middlename','$lastname','$gender','$birthdate','$state','$city','$address','$country','$pincode','$mobile','$password','$paypal','$date','$referral_user','$login_user')");
				echo mysqli_error($con);
				
				//Insert into income
				$query2 = mysqli_query($con,"insert into income(`email`) values('$email')");
				echo mysqli_error($con);
				
				/* commit transaction */
				if ($query1 && $query2) {
					mysqli_commit($con);
					echo 1;
				}
				else{
					mysqli_rollback($con);
					echo 'Their are some internal poroblem. Please try again after some time.';
				}

				/* close connection */
				mysqli_close($con);
			}
			else{
				//If referral id is not available
				echo 'Referral user dosn\'t exit.';
			}
		}//If pan card is not already used.
		else{
			echo 'This email id is already used. Plese try with different one.';
		}//If pan card is userd.
	}//No field is empty.
}//If firs name exist.
else{
	echo '<script>alert("Access denied");window.location.assign("../../../login.php");</script>';
}
?>
<?php
//All functions
//Check for empty fields
function check_empty_field($firstname,$lastname,$gender,$mobile,$birthdate,$email,$country,$address,$state,$city,$pincode,$referral_user){
	global $flag;
	if($firstname==""){
		$flag=1;
		echo 'Please fill in First Name';
	}
	else if($lastname==""){
		$flag=1;
		echo 'Please fill in Last Name';
	}
	else if($gender==""){
		$flag=1;
		echo 'Please select Gender';
	}
	else if($mobile==""){
		$flag=1;
		echo 'Please fill in Mobile no';
	}
	else if($birthdate==""){
		$flag=1;
		echo 'Please select Birth Date';
	}
	else if($email==""){
		$flag=1;
		echo 'Please fill in Email Id';
	}
	else if($country==""){
		$flag=1;
		echo 'Please fill in Country ';
	}
	else if($address==""){
		$flag=1;
		echo 'Please fill in Street';
	}
	else if($state==""){
		$flag=1;
		echo 'Please select State';
	}
	else if($city==""){
		$flag=1;
		echo 'Please fill in City';
	}
	else if($pincode==""){
		$flag=1;
		echo 'Please fill your Pincode';
	}
	else if($referral_user==""){
		$flag=1;
		echo 'Please fill in Referral User';
	}
}

//Check pan card
function check_valid_userid($email){
	global $con;
	$query = mysqli_query($con,"select * from user where email='$email'");
	if(mysqli_num_rows($query)>0){
		return false;	
	}
	else{
		return true;
	}
}

//create userid
function create_userid(){
	global $con;
	$generate_userid = 'IT'.date("ymd").rand(100,999);
	$query = mysqli_query($con,"select * from user where userid='$generate_userid'");
	if(mysqli_num_rows($query)>0){
		create_userid();
	}
	else{
		return $generate_userid;
	}
}
?>
<?php
$to = $email;
$subject = 'Dalfay - Registration';

$message = "Thank you for registration with Dalfay. Your userid is ".$email." and password is ".$password." Visit http://www.dalfay.com";
$headers = "From: info@dalfay.com \r\nReply-To: info@dalfay.com";

mail($to, $subject, $message, $headers);
?>