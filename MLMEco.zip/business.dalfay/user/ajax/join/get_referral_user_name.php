<?php
session_start();
$login_user = $_SESSION['userid'];
include("../../../php-includes/connect.php");
include("../../../function/table-data.php");
$referral_user = mysqli_real_escape_string($con,$_POST['referral_user']);
$query = mysqli_query($con,"select * from user where email='$referral_user'");
if(mysqli_num_rows($query)>0){
	$result = mysqli_fetch_array($query);
	$f_name = $result['firstname'];
	$m_name = $result['middlename'];
	$l_name = $result['lastname'];
	
	echo ucfirst($f_name).' '.$m_name.' '.ucfirst($l_name);
}
else{
	echo 'Invalid Referral User';
}

?>