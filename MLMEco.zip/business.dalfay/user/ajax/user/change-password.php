<?php
session_start();
require('../../../php-includes/connect.php');
require('../../../function/table-data.php');
$userid = $_SESSION['userid'];
$user_data = user($userid);
if(isset($_POST['current'])){
include("../../../php-includes/connect.php");
	$current = mysqli_real_escape_string($con,$_POST['current']);
	$new = mysqli_real_escape_string($con,$_POST['new']);
	$confirm = mysqli_real_escape_string($con,$_POST['confirm']);
	
	$length = strlen($new);
	
	$flag=0;	
	check_empty_field($current,$new,$confirm);
	if($flag==0){
		//If all fields are available
		if($user_data['password']==$current){
			//If current passwod match 
			if($new==$confirm){
				//If both new and confirm passord are same
				if($length>=6){
					//If password is > 6
					mysqli_autocommit($con,FALSE);
						$query1 = mysqli_query($con,"update user set password='$new' where email='$userid'");
					/* commit transaction */
					if ($query1) {
						mysqli_commit($con);
						echo 1;
					}
					else{
						mysqli_rollback($con);
						echo 'Their are some internal poroblem. Please try again after some time.';
					}
	
					/* close connection */
					mysqli_close($con);	
				}
				else{
					echo 'Passowrd should contain at least 6 characters.';
				}
			}
			else{
				//If referral id is not available
				echo 'New Password and Confirm Password does not match.';
			}
		}//If pan card is not already used.
		else{
			echo 'Current Password does not match.';
		}//If pan card is userd.
	}//No field is empty.
}//If firs name exist.
else{
	echo '<script>alert("Access denied");window.location.assign("../../../login.php");</script>';
}
?>
<?php
//All functions
//Check for empty fields
function check_empty_field($current,$new,$confirm){
	global $flag;
	if($current==""){
		$flag=1;
		echo 'Please fill in Current Password';
	}
	else if($new==""){
		$flag=1;
		echo 'Please fill in New Password';
	}
	else if($confirm==""){
		$flag=1;
		echo 'Please fill in Confirm Password';
	}
}

?>