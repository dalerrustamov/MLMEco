﻿<?php
session_start();
require('../php-includes/connect.php');
require('../php-includes/function.php');
require('../function/table-data.php');
require('php-includes/check_login.php');

$basename = explode('.',basename($_SERVER['PHP_SELF']));
$page = "join";
$userid = $_SESSION['userid'];
$user_data = user($userid);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <title>Dalfay | Joining History</title>
    <!-- Favicon-->
     <link href="font-awesome-4.7.0/css/font-awesome.css" rel="stylesheet">
    <link rel="icon" href="favicon.ico" type="image/x-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,700&subset=latin,cyrillic-ext" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">

    <!-- Bootstrap Core Css -->
    <link href="plugins/bootstrap/css/bootstrap.css" rel="stylesheet">

    <!-- Waves Effect Css -->
    <link href="plugins/node-waves/waves.css" rel="stylesheet" />

    <!-- Animation Css -->
    <link href="plugins/animate-css/animate.css" rel="stylesheet" />

    <!-- Morris Chart Css-->
    <link href="plugins/morrisjs/morris.css" rel="stylesheet" />

    <!-- Custom Css -->
    <link href="css/style.css" rel="stylesheet">

    <!-- AdminBSB Themes. You can choose a theme from css/themes instead of get all themes -->
    <link href="css/themes/all-themes.css" rel="stylesheet" />
   
</head>

<body class="theme-red">
    <?php include('php-includes/header.php'); ?>

    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h3>Joining History</h3>
            </div>

            <!-- Widgets -->
            
            <!-- #END# Widgets -->
            <!-- CPU Usage -->
            <div class="row clearfix">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                    <div class="card">
                        <div class="body">
                        	<div class="table-responsive">
                            	<table class="table table-striped table-bordered">
                                	<thead>
                                	<tr class="bg-red">
                                    	<td>S.n.</td>
                                        <td>Email</td>
                                        <td>Mobile no</td>
                                        <td>Name</td>
                                        <td>Join Date</td>
                                        <td>Status</td>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php
									$i=1;
                                    	$query = mysqli_query($con,"select * from user where by_userid='$userid' order by id desc");
										if(mysqli_num_rows($query)>0){
											while($row=mysqli_fetch_array($query)){
												$data = user($row['email']);
											?>
                                            	<tr>
                                                	<td><?php echo $i ?></td>
                                                    <td><?php echo $data['email']; ?></td>
                                                    <td><?php echo $data['mobileno']; ?></td>
                                                    <td><?php echo ucfirst($data['firstname']).' '.ucfirst($data['middlename']).' '.ucfirst($data['lastname']); ?></td>
                                                    <td><?php echo $data['date']; ?></td>
                                                    <td><?php echo $data['status']; ?></td>
                                                </tr>
                                            <?php
												                    		
												$i++;
                                            }
										}
										else{
										?>
                                        	<tr>
                                            	<td colspan="7">You have no joining history.</td>
                                            </tr>
                                        <?php
										}
									?>
                                    </tbody>
                                </table>
                            </div><!--/.table-responsive-->
                        </div>
                    </div>
                </div>
            </div>
            <!-- #END# Content -->
        </div>
    </section>

    <!-- Jquery Core Js -->
    <script src="plugins/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core Js -->
    <script src="plugins/bootstrap/js/bootstrap.js"></script>

    <!-- Select Plugin Js -->
    <script src="plugins/bootstrap-select/js/bootstrap-select.js"></script>

    <!-- Slimscroll Plugin Js -->
    <script src="plugins/jquery-slimscroll/jquery.slimscroll.js"></script>

    <!-- Waves Effect Plugin Js -->
    <script src="plugins/node-waves/waves.js"></script>

    <!-- Jquery CountTo Plugin Js -->
    <script src="plugins/jquery-countto/jquery.countTo.js"></script>

    <!-- Morris Plugin Js -->
    <script src="plugins/raphael/raphael.min.js"></script>
    <script src="plugins/morrisjs/morris.js"></script>

    <!-- ChartJs -->
    <script src="plugins/chartjs/Chart.bundle.js"></script>

    <!-- Flot Charts Plugin Js -->
    <script src="plugins/flot-charts/jquery.flot.js"></script>
    <script src="plugins/flot-charts/jquery.flot.resize.js"></script>
    <script src="plugins/flot-charts/jquery.flot.pie.js"></script>
    <script src="plugins/flot-charts/jquery.flot.categories.js"></script>
    <script src="plugins/flot-charts/jquery.flot.time.js"></script>

    <!-- Sparkline Chart Plugin Js -->
    <script src="plugins/jquery-sparkline/jquery.sparkline.js"></script>

    <!-- Custom Js -->
    <script src="js/admin.js"></script>
    <script src="js/pages/index.js"></script>

    <!-- Demo Js -->
    <script src="js/demo.js"></script>
</body>

</html>