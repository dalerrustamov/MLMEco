<!-- Page Loader -->
  
    <!-- #END# Page Loader -->
    <!-- Overlay For Sidebars -->
    <div class="overlay"></div>
    <!-- #END# Overlay For Sidebars -->
    <!-- Search Bar -->
    
    <!-- #END# Search Bar -->
    <!-- Top Bar -->
    <nav class="navbar">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="javascript:void(0);" class="bars"></a>
                <a class="navbar-brand" href="index.php">
                	<!--<img src="images/logo.png" width="150" style="margin-top:-10px" class="img-responsive">-->
                    <h4>DALFAY</h4>
              	</a>
            </div>
            <div class="collapse navbar-collapse" id="navbar-collapse">
                
            </div>
        </div>
    </nav>
    <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar">
            <!-- User Info -->
            <div class="user-info">
                <div class="image">
                	<?php 
						if(file_exists("profile/".$user_data['email'].".jpg")){
					?>
                    <img src="profile/<?php echo $user_data['email'] ?>.jpg" width="48" height="48" alt="User" />
                    <?php
						}
					?>
                </div>
                <div class="info-container">
                    <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $user_data['firstname'].' '.$user_data['middlename'].' '.$user_data['lastname']; ?></div>
                    <div class="email"><?php echo $user_data['email']; ?></div>
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu">
                <ul class="list">
                    <li class="<?php if($page=='index') echo 'active'; ?>">
                        <a href="index.php">
                            <i class="material-icons">home</i>
                            <span>Home</span>
                        </a>
                    </li>
                    <li class="<?php if($page=='user') echo 'active'; ?>">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">perm_identity</i>
                            <span>User</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="user-profile.php">Profile</a>
                            </li>
                            <li>
                            <li>
                                <a href="user-change-password.php">Change Password</a>
                            </li>
                        </ul>
                    </li>
                    <li class="<?php if($page=='join') echo 'active'; ?>">
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">playlist_add</i>
                            <span>Join</span>
                        </a>
                        <ul class="ml-menu">
                            <li>
                                <a href="new-joining.php">New Joining</a>
                            </li>
                            <li>
                                <a href="join-history.php">History</a>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <a href="../logout.php">
                        	<i class="material-icons">power_settings_new</i>
                            <span>Logout</span>

                        </a>
                    </li>
                </ul>
            </div>
            <!-- #Menu -->
            <!-- Footer -->
            <div class="legal">
                <div class="copyright">
                    &copy; 2017 <a href="http://www.3sinfobit.com" target="_blank">Designed & Managed by 3S Infobit</a>.
                </div>
            </div>
            <!-- #Footer -->
        </aside>
    </section>
