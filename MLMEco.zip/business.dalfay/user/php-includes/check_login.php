<?php 
if($_SESSION['sid_user']==session_id())
	{
			if($_SESSION['login_type']=="user")
			{
				
			}
			else
			{
				header("Location: ../login.php");
			}
	}
	else
	{
		header("location: ../login.php");
	}

?>