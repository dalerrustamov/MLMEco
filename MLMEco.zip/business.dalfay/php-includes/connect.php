<?php
	$db_host="localhost";
	$db_user="daler";
	$db_pass="daler123";
	
	$db_name="elloween";
	
	
	$con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
	if(mysqli_connect_errno()){
		echo "Faild to connect to database".mysqli_connect_error();
	}
	
	
	
?>