<?php
function user_profile($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from user where userid='$userid'");
	
	$result = mysqli_query($con,"SHOW COLUMNS FROM user");
	
	$query_data_value = mysqli_fetch_array($query);
	
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			$col = $row['Field'];
			$data[$col] = $query_data_value[$col];
		}
	}
	return $data;
}
function package_name_by_id($id){
	global $con;
	$query = mysqli_query($con,"select * from package where id='$id'");
	$result = mysqli_fetch_array($query);
	return $result['name'];
}
function user_list(){
	global $con;
	$query = mysqli_query($con,"select * from user");
	while($row=mysqli_fetch_array($query)){
		$email = $row['email'];
		echo '<option>'.$email.'</option>';
	}
}
?>