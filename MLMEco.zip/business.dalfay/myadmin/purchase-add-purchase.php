<?php
include('../php-includes/connect.php');
include('php-includes/check-login.php');
require('../php-includes/function.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Add Purchase</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="dist/css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    
 		
	

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php include('php-includes/menu.php'); ?>

        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row page-header">
                    <div class="col-lg-12">
                        <h4>Add Purchase</h4>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                	<div class="col-lg-6">
                    	<form>
                        	<div class="row form-group">
                            	<div class="col-lg-4">
                                	<label>Order ID</label>
                                </div>
                                <div class="col-lg-8">
                                	<div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-shopping-basket"></i>
                                        </span>
                                        <input type="text" name="orderid" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                            	<div class="col-lg-4">
                                	<label>Email</label>
                                </div>
                                <div class="col-lg-8">
                                	<div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-at"></i>
                                        </span>
                                       	<select name="email" class="form-control" required>
                                            <option>Select Email</option>
                                            <?php user_list(); ?>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                            	<div class="col-lg-4">
                                	<label>Amount</label>
                                </div>
                                <div class="col-lg-8">
                                	<div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-dollar"></i>
                                        </span>
                                       	<input type="text" id="amount" name="amount" class="form-control">
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                            	<div class="col-lg-4">
                                	<label>Date</label>
                                </div>
                                <div class="col-lg-8">
                                    <div class="input-group">
                                        <span class="input-group-addon">
                                            <i class="fa fa-calendar"></i>
                                        </span>
                                        <input type="text" id="orderdate" name="date" class="form-control" placeholder="dd-mm-yy">
                                    </div>
                               	</div>
                            </div>
                            <div class="row form-group">
                            	<div class="col-lg-4"></div>
                            	<div class="col-lg-8">
                                	<input type="submit" name="submit" value="Add Purchase" class="btn btn-primary">
                                </div>
                            </div>
                        </form>
                    </div><!--col-lg-6-->
                </div><!--/.row-->
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- jQuery -->
    <script src="vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="dist/js/sb-admin-2.js"></script>
    <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script>
		$( function() {
		$( "#orderdate" ).datepicker(
			{
				minDate: -20, 
        		maxDate: 0,
         		yearRange: "1955:2005",
				dateFormat: 'yy-mm-dd'
				//maxDate: "+1M +10D"
			});
		} );
  	</script>

</body>

</html>
