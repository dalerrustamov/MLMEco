<?php
include('../php-includes/connect.php');
include('php-includes/check-login.php');

//Empty the tables
mysqli_query($con,"truncate table user");
mysqli_query($con,"truncate table tree");
mysqli_query($con,"truncate table payment_request");
mysqli_query($con,"truncate talbe income");

$userid = "IT1111";

//Inset into tables
mysqli_query($con,"insert into user(`userid`,`email`,`firstname`,`lastname`,`gender`,`dob`,`state`,`city`,`address`,`pincode`,`mobileno`,`password`,`package_id`,`image_id`,`status`) values('$userid','santoshdevnath15@gmail.com','Santosh','Devnath','Male','2017-01-04','Uttarakhand','Shaktifarm','Shaktifarm market','263151','9897883700','123456','1','IT1111','Activated')");

mysqli_query($con,"insert into tree(`userid`) values('$userid')");

mysqli_query($con,"insert into payment_request(`userid`,`package_id`,`payment_mode`,`bank_name`,`date`,`status`,`close_date`) values('$userid','1','Cash','SBI','2017-01-04','Close','2017-01-04')");

mysqli_query($con,"insert into income(`userid`) values('$userid')");
echo mysqli_error($con);
?>