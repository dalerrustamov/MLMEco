<?php
include('../php-includes/connect.php');
include('php-includes/check-login.php');
require('../php-includes/function.php');
require('../function/table-data.php');
?>
<?php
mysqli_autocommit($con,FALSE);
	$query1 = mysqli_query($con,"update test set title='Hello3' where id='1'");
	$query2 = mysqli_query($con,"select * from test where id='1'");
	$result = mysqli_fetch_array($query2);
	echo $result['title'];
	
if($query1){
	mysqli_commit($con);
	echo 'Done';
}
else{
	mysqli_rollback($con);
	echo 'False';
}
?>