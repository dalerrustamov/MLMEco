-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 04, 2017 at 07:36 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elloween`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_all`
--

CREATE TABLE `add_all` (
  `id` int(11) NOT NULL,
  `company_id` varchar(20) NOT NULL,
  `add_name` varchar(30) NOT NULL,
  `url` varchar(255) NOT NULL,
  `state` varchar(20) NOT NULL,
  `gender` enum('All','Male','Female') NOT NULL DEFAULT 'All',
  `age_from` int(11) NOT NULL,
  `age_to` int(11) NOT NULL,
  `total_add` int(11) NOT NULL,
  `remaining_add` int(11) NOT NULL,
  `day_click` int(11) NOT NULL,
  `daily_limit` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_all`
--

INSERT INTO `add_all` (`id`, `company_id`, `add_name`, `url`, `state`, `gender`, `age_from`, `age_to`, `total_add`, `remaining_add`, `day_click`, `daily_limit`) VALUES
(1, 'ITCPOS', 'Heating Belt', 'http://www.posgroup.in', 'Uttarakhand', 'All', 10, 30, 500, 470, 10, 15),
(2, 'ITCPOS', 'LS Belt', 'http://www.posgroup.in/prosthetics.php', 'Uttarakhand', 'All', 10, 30, 500, 500, 0, 15);

-- --------------------------------------------------------

--
-- Table structure for table `add_backup`
--

CREATE TABLE `add_backup` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `url` varchar(200) NOT NULL,
  `total_click` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_backup`
--

INSERT INTO `add_backup` (`id`, `name`, `url`, `total_click`) VALUES
(1, 'Inet Bazar', 'http://www.inetbazar.com', 1);

-- --------------------------------------------------------

--
-- Table structure for table `add_company`
--

CREATE TABLE `add_company` (
  `id` int(11) NOT NULL,
  `company_id` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `add_package_id` int(11) NOT NULL,
  `status` enum('Active','Deactive') NOT NULL DEFAULT 'Deactive'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_company`
--

INSERT INTO `add_company` (`id`, `company_id`, `password`, `add_package_id`, `status`) VALUES
(1, 'ITCPOS', '123456', 1, 'Deactive');

-- --------------------------------------------------------

--
-- Table structure for table `add_package`
--

CREATE TABLE `add_package` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `click` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_package`
--

INSERT INTO `add_package` (`id`, `name`, `price`, `click`) VALUES
(1, 'First', 2500, 500);

-- --------------------------------------------------------

--
-- Table structure for table `admin_login`
--

CREATE TABLE `admin_login` (
  `id` int(11) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

INSERT INTO `admin_login` (`id`, `userid`, `password`) VALUES
(1, 'mlm', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `income`
--

CREATE TABLE `income` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `current_cash` int(11) NOT NULL,
  `total_cash` int(11) NOT NULL,
  `wallet` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `income`
--

INSERT INTO `income` (`id`, `userid`, `current_cash`, `total_cash`, `wallet`) VALUES
(1, 'IT1111', 2000, 2000, 500),
(11, 'IT170203739', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `package`
--

CREATE TABLE `package` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `capping` int(11) NOT NULL,
  `click` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `days` int(11) NOT NULL,
  `back_color` varchar(10) NOT NULL,
  `status` enum('Activate','Deactivate') NOT NULL DEFAULT 'Activate',
  `total_purchased` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `package`
--

INSERT INTO `package` (`id`, `name`, `price`, `capping`, `click`, `rate`, `days`, `back_color`, `status`, `total_purchased`) VALUES
(1, 'Inet Starter', 2500, 1250, 5, 5, 200, 'red', 'Activate', 0),
(2, 'Inet Basic', 5000, 2500, 10, 5, 200, 'cyan', 'Activate', 0),
(3, 'Inet Bronze', 10000, 5000, 20, 5, 200, 'green', 'Activate', 0),
(4, 'Inet Silver', 25000, 12500, 50, 5, 200, 'orange', 'Activate', 0),
(5, 'Inet Gold', 50000, 25000, 100, 5, 200, 'blue-grey', 'Activate', 7),
(6, 'Inet Diamond', 100000, 50000, 200, 5, 200, 'pink', 'Activate', 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment_request`
--

CREATE TABLE `payment_request` (
  `id` int(11) NOT NULL,
  `userid` varchar(20) NOT NULL,
  `package_id` int(11) NOT NULL,
  `payment_mode` varchar(20) NOT NULL,
  `bank_name` varchar(30) NOT NULL,
  `date` date NOT NULL,
  `status` enum('Open','Close','Cancel') NOT NULL DEFAULT 'Open',
  `close_date` date NOT NULL,
  `cancel_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_request`
--

INSERT INTO `payment_request` (`id`, `userid`, `package_id`, `payment_mode`, `bank_name`, `date`, `status`, `close_date`, `cancel_date`) VALUES
(8, 'IT170203739', 5, 'Cash', 'BOB', '2017-02-03', 'Close', '2017-02-03', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `setting_income`
--

CREATE TABLE `setting_income` (
  `id` int(11) NOT NULL,
  `referral_income` int(11) NOT NULL,
  `referral_cash` int(11) NOT NULL,
  `referral_wallet` int(11) NOT NULL,
  `add_cash` int(11) NOT NULL,
  `add_wallet` int(11) NOT NULL,
  `add_tds` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `setting_income`
--

INSERT INTO `setting_income` (`id`, `referral_income`, `referral_cash`, `referral_wallet`, `add_cash`, `add_wallet`, `add_tds`) VALUES
(1, 5, 80, 20, 85, 5, 10);

-- --------------------------------------------------------

--
-- Table structure for table `test`
--

CREATE TABLE `test` (
  `id` int(11) NOT NULL,
  `title` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test`
--

INSERT INTO `test` (`id`, `title`) VALUES
(1, 'Hello3');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `userid` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `firstname` varchar(30) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `gender` enum('Male','Female') NOT NULL DEFAULT 'Male',
  `dob` date NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `address` varchar(80) DEFAULT NULL,
  `pincode` int(11) NOT NULL DEFAULT '0',
  `mobileno` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  `bankname` varchar(50) DEFAULT NULL,
  `branch` varchar(20) DEFAULT NULL,
  `accountno` varchar(20) NOT NULL DEFAULT ' ',
  `ifsccode` varchar(20) NOT NULL DEFAULT ' ',
  `date` date DEFAULT NULL,
  `pan` varchar(20) NOT NULL DEFAULT ' ',
  `referral_user` varchar(30) DEFAULT NULL,
  `package_id` int(11) NOT NULL,
  `day_click` int(11) NOT NULL,
  `total_day` int(11) NOT NULL,
  `image_id` varchar(20) NOT NULL,
  `by_userid` varchar(20) NOT NULL,
  `status` enum('Activated','Deactivated','Pending','Cancelled','Completed') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `userid`, `email`, `firstname`, `lastname`, `gender`, `dob`, `state`, `city`, `address`, `pincode`, `mobileno`, `password`, `bankname`, `branch`, `accountno`, `ifsccode`, `date`, `pan`, `referral_user`, `package_id`, `day_click`, `total_day`, `image_id`, `by_userid`, `status`) VALUES
(1, 'IT1111', 'santoshdevnath15@gmail.com', 'Santosh', 'Devnath', 'Male', '1994-01-05', 'Delhi', 'Shaktifarm', 'Shaktifarm market', 263151, '9897883700', '123456', NULL, NULL, ' ', ' ', NULL, ' ', NULL, 1, 1, 0, 'IT1111', '', 'Activated'),
(10, 'IT170203739', 'suresh@gmail.com', 'Suresh', 'Biswas', 'Male', '2002-04-12', 'Haryana', 'Gurgaon', 'Gurgaon', 122001, '9897883700', '123456', NULL, NULL, ' ', ' ', '2017-02-03', 'AB89890J', 'IT1111', 5, 0, 0, 'IT170203739', 'IT1111', 'Activated');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_all`
--
ALTER TABLE `add_all`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_backup`
--
ALTER TABLE `add_backup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_company`
--
ALTER TABLE `add_company`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_package`
--
ALTER TABLE `add_package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_login`
--
ALTER TABLE `admin_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `income`
--
ALTER TABLE `income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `package`
--
ALTER TABLE `package`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_request`
--
ALTER TABLE `payment_request`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting_income`
--
ALTER TABLE `setting_income`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test`
--
ALTER TABLE `test`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_all`
--
ALTER TABLE `add_all`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `add_backup`
--
ALTER TABLE `add_backup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `add_company`
--
ALTER TABLE `add_company`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `add_package`
--
ALTER TABLE `add_package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `admin_login`
--
ALTER TABLE `admin_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `income`
--
ALTER TABLE `income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `package`
--
ALTER TABLE `package`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `payment_request`
--
ALTER TABLE `payment_request`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `setting_income`
--
ALTER TABLE `setting_income`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `test`
--
ALTER TABLE `test`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
