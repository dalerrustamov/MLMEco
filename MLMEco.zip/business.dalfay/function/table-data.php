<?php
function user($email){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from user where email='$email'");
	$result = mysqli_fetch_array($query);
	$data['email'] = $result['email'];
	$data['firstname'] = $result['firstname'];
	$data['middlename'] = $result['middlename'];
	$data['lastname'] = $result['lastname'];
	$data['gender'] = $result['gender'];
	$data['dob'] = $result['dob'];
	$data['state'] = $result['state'];
	$data['city'] = $result['city'];
	$data['address'] = $result['address'];
	$data['country'] = $result['country'];
	$data['pincode'] = $result['pincode'];
	$data['mobileno'] = $result['mobileno'];
	$data['password'] = $result['password'];
	$data['bankname'] = $result['bankname'];
	$data['branch'] = $result['branch'];
	$data['accountno'] = $result['accountno'];
	$data['ifsccode'] = $result['ifsccode'];
	$data['paypal'] = $result['paypal'];
	$data['date'] = $result['date'];
	$data['pan'] = $result['pan'];
	$data['referral_user'] = $result['referral_user'];
	$data['by_userid'] = $result['by_userid'];
	$data['status'] = $result['status'];
	
	return $data;
}
function user_only_activated($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from user where userid='$userid'");
	$result = mysqli_fetch_array($query);
	if($result['status']!="Activated"){
		user_only_activated($result['u_id']);
	}
	else{
		$data['email'] = $result['email'];
		$data['firstname'] = $result['firstname'];
		$data['lastname'] = $result['lastname'];
		$data['gender'] = $result['gender'];
		$data['dob'] = $result['dob'];
		$data['state'] = $result['state'];
		$data['city'] = $result['city'];
		$data['address'] = $result['address'];
		$data['pincode'] = $result['pincode'];
		$data['mobileno'] = $result['mobileno'];
		$data['password'] = $result['password'];
		$data['bankname'] = $result['bankname'];
		$data['branch'] = $result['branch'];
		$data['accountno'] = $result['accountno'];
		$data['ifsccode'] = $result['ifsccode'];
		$data['u_id'] = $result['u_id'];
		$data['place'] = $result['place'];
		$data['date'] = $result['date'];
		$data['pan'] = $result['pan'];
		$data['sponsor_id'] = $result['sponsor_id'];
		$data['package_id'] = $result['package_id'];
		$data['image_id'] = $result['image_id'];
		$data['status'] = $result['status'];
		return $data;	
	}
}

function package($package_id){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from package where id='$package_id'");
	$result = mysqli_fetch_array($query);
	$data['name'] = $result['name'];
	$data['price'] = $result['price'];
	$data['capping'] = $result['capping'];
	$data['click'] = $result['click'];
	$data['rate'] = $result['rate'];
	$data['days'] = $result['days'];
	$data['back_color'] = $result['back_color'];
	$data['status'] = $result['status'];
	$data['total_purchased'] = $result['total_purchased'];
	
	return $data;
}

function income($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from income where userid='$userid'");
	$result = mysqli_fetch_array($query);
	$data['current_cash'] = $result['current_cash'];
	$data['total_cash'] = $result['total_cash'];
	$data['wallet'] = $result['wallet'];
	
	return $data;
}

function setting_income(){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from setting_income");
	$result = mysqli_fetch_array($query);
	$data['referral_income'] = $result['referral_income'];
	$data['referral_cash'] = $result['referral_cash'];
	$data['referral_wallet'] = $result['referral_wallet'];
	$data['add_cash'] = $result['add_cash'];
	$data['add_wallet'] = $result['add_wallet'];
	$data['add_tds'] = $result['add_tds'];
	
	return $data;
}

function tree($userid){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from tree where userid='$userid'");
	$result = mysqli_fetch_array($query);
	$data['left_userid'] = $result['left_userid'];
	$data['right_userid'] = $result['right_userid'];
	$data['left_count'] = $result['left_count'];
	$data['right_count'] = $result['right_count'];
	
	return $data;
}

function add_all($id){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from add_all where id='$id'");
	$result = mysqli_fetch_array($query);
	$data['company_id'] = $result['company_id'];
	$data['add_name'] = $result['add_name'];
	$data['url'] = $result['url'];
	$data['state'] = $result['state'];
	$data['gender'] = $result['gender'];
	$data['age_from'] = $result['age_from'];
	$data['age_to'] = $result['age_to'];
	$data['total_add'] = $result['total_add'];
	$data['remaining_add'] = $result['remaining_add'];
	$data['day_click'] = $result['day_click'];
	$data['daily_limit'] = $result['daily_limit'];
	
	return $data;
}

function add_backup($id){
	global $con;
	$data = array();
	$query = mysqli_query($con,"select * from add_backup where id='$id'");
	$result = mysqli_fetch_array($query);
	$data['total_click'] = $result['total_click'];
	
	return $data;
}
?>